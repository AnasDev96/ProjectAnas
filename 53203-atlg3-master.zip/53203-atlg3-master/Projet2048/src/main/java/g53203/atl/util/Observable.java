package g53203.atl.util;

/**
 * Interface Observer, for Update different class
 *
 * @author Anas Benallal 53203
 */
public interface Observable {

    /**
     * Method for Update data
     */
    void upDate();

}
