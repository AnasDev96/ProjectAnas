Anas Benallal 53203
Projet pour ATLG3 année 2020-2021


Bienvenu dans le jeux 2048 ! 

le jeux se joue à un seul joueur, le but est de réussir à obtenir le chiffre 2048
dans le plateau du jeux, en effectuant des mouvements, à droite à gauche vers le bas
et vers le haut. Les touches des commandes se construient comme ceci:
   5
1  2  3 

5: vers le haut
2: vers le bas 
3: vers la droite 
1: vers la gauche

Vous aurez une vue comme ceci : 
----------------------------
|     ||     ||     ||     |
|     ||     ||     ||     |
|     ||     ||     ||     |
----------------------------
|     ||     ||     ||     |
|     ||     ||     ||     |
|     ||     ||     ||     |
----------------------------
|     ||     ||     ||     |
|     ||     ||  4  ||     |
|     ||     ||     ||     |
----------------------------
|     ||     ||     ||     |
|     ||     ||     ||     |
|     ||     ||     ||     |
----------------------------

Le jeux s'arrête lorsque vous obtenez le chiffre 2048, ou si vous êtes bloqué dans le jeux.

Bon amusement ! :)

Pour la partie JavaFx, vous pourrez avoir l'option recommencer, et les mouvements se font avec les touches directionnel !

