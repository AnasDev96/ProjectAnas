package g53203.atl.fx.bmr.util;

/**
 * Interface Observer, for Update different class
 *
 * @author Anas Benallal - 53203
 */
public interface Observer {

    /**
     * Method for Update data
     */
    void upDate();

}
