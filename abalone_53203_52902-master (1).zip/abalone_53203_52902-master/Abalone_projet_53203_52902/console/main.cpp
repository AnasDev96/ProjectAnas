#include <iostream>
#include "Controller.h"

using namespace std;

int main()
{
    Controller controller = Controller();
    controller.play();
}
