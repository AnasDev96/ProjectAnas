/**
 * Project ProjetAbalon_53203_52902
 */
#ifndef PLAYERCOLOR_H
#define PLAYERCOLOR_H

/*!
 * \enum PlayerColor
 * \brief PlayerColor enum
 */
enum PlayerColor {

    NONE,/*!<the color NONE >*/
    RED,/*!<the color red >*/
    BLUE /*!<the color blue>*/

};

#endif //PLAYERCOLOR_H

