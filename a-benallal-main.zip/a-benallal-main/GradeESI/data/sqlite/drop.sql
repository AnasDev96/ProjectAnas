------------------------------------------
-- Détruire les tables si elles existaient
------------------------------------------

DROP TABLE GRADES;
DROP TABLE LESSONS;
DROP TABLE STUDENTS;
