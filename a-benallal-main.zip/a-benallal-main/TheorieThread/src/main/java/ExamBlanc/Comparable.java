
package ExamBlanc;

/**
 *
 * @author anasbenallal
 */
public interface Comparable<T> {
    public Integer compareTo(T other);
}
