
package ThreadObjet;

/**
 *
 * @author g53203
 */
public class ToujoursPair {
   
    private int i = 0 ;
    
    public void nextI(){
       // i= i +1 ;
        ++i;
        ++i;
    }

    public int getI() {
        return i;
    }
    
}
