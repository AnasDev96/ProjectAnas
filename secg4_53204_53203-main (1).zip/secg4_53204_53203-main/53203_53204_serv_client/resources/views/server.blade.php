@extends('canevas')
@section('title','server')
@section('serv')

<main><h1>Upload</h1> <a href="/upload" class="btn btn-primary">UPLOAD</a> <br></main>
<main><h1>Delete</h1><a href="/delete" class="btn btn-primary">DELETE</a> <br></main>
<main><h1>Download</h1><a href="/download" class="btn btn-primary">DOWNLOAD</a> <br></main>

@endsection