@extends('canevas')
@section('title','Home')
@section('home')


<nav>
    <ul>
        <li><a href="/login">Login</a></li>
        <li><a href="/register">Register</a></li>
    </ul>
</nav>
@endsection